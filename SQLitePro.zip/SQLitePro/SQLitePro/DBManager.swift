//
//  DBManager.swift
//  SQLitePro
//
//  Created by Zap.Danish on 01/05/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit
import FMDB


class DBManager: NSObject {
    
    static let shared: DBManager = DBManager()
    let databaseFileName = "database.sqlite"
    var pathTodatabase:String!
    var database: FMDatabase!
    var searchedEmail:String?
    
    override init(){
        super.init()
        
        let documentsDirectory = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString) as String
        pathTodatabase = documentsDirectory.appending("/\(databaseFileName)")
    }

    func createDataBase()-> Bool{
        var created = false
        
        if !FileManager.default.fileExists(atPath: pathTodatabase){
            database = FMDatabase(path: pathTodatabase!)

            if database != nil{
                if database.open(){
                    let createUserDetailsTableQuery = "CREATE TABLE USER (USER_ID INTEGER  PRIMARY KEY AUTOINCREMENT NOT NULL,EMAIL VARCHAR NOT NULL,PASSWORD VARCHAR)"
                    do{
                       try database.executeStatements(createUserDetailsTableQuery)
                        created = true
                    }
                    catch{
                        print("couldn't create table")
                        print(error.localizedDescription)
                        }
                    database.close()
                }else{
                    print("couldn't open the Database")
                }
            }
        }
        return created
    }
    
    
    func openDataBase()-> Bool{
        if database == nil{
            if FileManager.default.fileExists(atPath: pathTodatabase){
                database = FMDatabase(path: pathTodatabase)
            }
        }
        if database != nil{
            if database.open(){
                return true
            }
        }
        return false
    }
    
    
    
    func insertData(email:String,password:String)->Bool{
        guard database.isOpen else {
            return false
        }
        let insertValueQuery = "INSERT INTO USER (EMAIL,PASSWORD) values ('\(email)','\(password)')"
        let value =  database.executeStatements(insertValueQuery)
        if value{
          database.commit()
         return true
        }else{
            return false
        }
    }
    
    
    func getData() {
        let getValue = "SELECT * FROM USER"
        let result = database.executeQuery(getValue, withArgumentsIn: [])
        while (result?.next())! {
            print(result?.string(forColumn: "EMAIL"))
            print(result?.string(forColumn: "PASSWORD"))
            print(result?.string(forColumn: "USER_ID"))
        }
    }
    
    
    func showPassword(email:String)->String{
        let selectEmailQuery = "SELECT * FROM USER WHERE EMAIL  = '\(email)'"
        let result = database.executeQuery(selectEmailQuery, withArgumentsIn: [])
        while (result?.next())! {
            return result?.string(forColumn: "PASSWORD") ?? "error"
        }
        return "Please Enter currect Email"
    }
    
    
    func signIn(email:String,password:String)-> Bool{
        let selectEmailQuery = "SELECT * FROM USER WHERE EMAIL  = '\(email)'"
        let result = database.executeQuery(selectEmailQuery, withArgumentsIn: [])
        while (result?.next())! {
            if result?.string(forColumn: "PASSWORD") == password && email == result?.string(forColumn: "EMAIL"){
                return true
            }
        }
        return false
    }
    
    
}

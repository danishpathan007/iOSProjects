//
//  ViewController.swift
//  SQLitePro
//
//  Created by Zap.Danish on 01/05/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit
import FMDB

class ViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(DBManager.shared.createDataBase())
        print(DBManager.shared.openDataBase())
    }


    @IBAction func signupTapped(_ sender: UIButton) {
        let email = emailTextField.text!
        let password = passwordTextField.text!
        if  DBManager.shared.insertData(email: email, password: password) == true{
            passwordTextField.text! = ""
            let alert = UIAlertController(title: "Signup", message: "Sucessfully", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert,animated: true,completion: nil)
        }
        
    }
    
    @IBAction func forgetPasswordTapped(_ sender: UIButton) {
       DBManager.shared.getData()
        let result = DBManager.shared.showPassword(email: emailTextField.text!)
      passwordTextField.text = "\(result)"
      
        
    }
    
    @IBAction func sighInTapped(_ sender:UIButton){
        
        let check = DBManager.shared.signIn(email: emailTextField.text!, password: passwordTextField.text!)
        
        if check{
            let alert = UIAlertController(title: "Login", message: "Sucessfully", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert,animated: true,completion: nil)
        }else{
            let alert = UIAlertController(title: "Password", message: "dosen't match", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert,animated: true,completion: nil)
        
        }
        
        
    }
    
}


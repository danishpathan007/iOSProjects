//
//  LoginViewController.swift
//  UMS
//
//  Created by Zap.Danish on 11/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    var name: String?
    var email:String?
    var password:String?
    var retypePassword:String?
    var contact:String?
    var program:String?
    
    @IBOutlet weak var loginEmailTextField: UITextField!
    @IBOutlet weak var loginPasswordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
   
    }

    
    @IBAction func loginButtonClicked(_ sender: Any) {
        if !(loginEmailTextField.text?.isEmpty)! && !(loginPasswordTextField.text?.isEmpty)!{
     performSegue(withIdentifier: "goToProfile", sender: nil)
        }else{
            
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "goToProfile"{
            _ = segue.destination as! HomeViewController
        }
        
    }
    

}


//
//  SignupViewController.swift
//  UMS
//
//  Created by Zap.Danish on 11/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var retypePasswordTextField: UITextField!
    @IBOutlet weak var contactTextField: UITextField!
    @IBOutlet weak var programTextField: UITextField!
    @IBOutlet weak var genderSegment: UISegmentedControl!
    @IBOutlet weak var signupButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

    @IBAction func signupClicked(_ sender: UIButton) {
        
        if checkValidation() == true{
        if let controllers = self.navigationController?.viewControllers{
            for controller in controllers{
                if let loginController = controller as? LoginViewController{
                   loginController.name = nameTextField.text
                   loginController.email = emailTextField.text
                   loginController.password = passwordTextField.text
                   loginController.retypePassword = retypePasswordTextField.text
                   loginController.contact = contactTextField.text
                   loginController.program = programTextField.text
                   self.navigationController?.popToViewController(loginController,animated: true)
                   break
                }
            }
        }
        }else{
             signupButton.titleLabel?.text = "Fill all"
        }
    }
    
    func checkValidation()->Bool{
        if !(nameTextField.text?.isEmpty)! && !(emailTextField.text?.isEmpty)! && !(passwordTextField.text?.isEmpty)! && !(retypePasswordTextField.text?.isEmpty)! && !(contactTextField.text?.isEmpty)! && !(programTextField.text?.isEmpty)! {
            return true
        }
        else{
            return false
        }
    }
}

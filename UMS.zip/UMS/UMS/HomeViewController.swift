//
//  HomeViewController.swift
//  UMS
//
//  Created by Zap.Danish on 11/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
      navigationController?.isNavigationBarHidden = true
        
    }
}

//
//  MainViewController.swift
//  LoginDataPassing
//
//  Created by Danish Pathan on 21/02/19.
//  Copyright © 2019 Danish Pathan. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var emailId: UITextField!
    @IBOutlet weak var phoneNumber: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var retypePassword: UITextField!
    
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
    @IBAction func registerButtonClicked(_ sender: UIButton) {
        if !checkIfEmpty() {
            self.performSegue(withIdentifier: "passData", sender: nil)
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is LoginViewController{
           
        let viewController = segue.destination as? LoginViewController
        
        viewController?.name = name.text!
        viewController?.emailid = emailId.text!
        viewController?.phoneNumber = phoneNumber.text!
        viewController?.password = password.text!
        viewController?.retypePassword = retypePassword.text!
        
        }
    }
    
    private func checkIfEmpty() -> Bool {
        if name.text!.isEmpty && emailId.text!.isEmpty && phoneNumber.text!.isEmpty && password.text!.isEmpty && retypePassword.text!.isEmpty {
            return true
        }
        return false
    }

}


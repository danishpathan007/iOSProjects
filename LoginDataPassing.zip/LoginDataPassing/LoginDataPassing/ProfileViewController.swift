//
//  ProfileViewController.swift
//  LoginDataPassing
//
//  Created by Danish Pathan on 21/02/19.
//  Copyright © 2019 Danish Pathan. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    var profileName = String()
    var profileEmailid = String()
    var profilePhoneNumber = String()
    var profilePassword = String()
    var profileRetypePassword = String()
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var phoneNumber: UILabel!
    @IBOutlet weak var changePassword: UITextField!
    @IBOutlet weak var changeRetypePassword: UITextField!
    
  
    override func viewDidLoad() {
        super.viewDidLoad()
        name.text = profileName
        email.text = profileEmailid
        phoneNumber.text = profilePhoneNumber
        changePassword.text = profilePassword
        changeRetypePassword.text = profileRetypePassword

        
    }

    

    @IBAction func changePassword(_ sender: UIButton) {
        
            if let controllers = self.navigationController?.viewControllers{
                    for controller in controllers{
                    print(controllers)
                    if let loginViewController = controller as? LoginViewController{
        
                    loginViewController.password = changePassword.text!
                self.navigationController?.popToViewController(loginViewController, animated: true)
                    break
                }
    
          }
    }
}

}

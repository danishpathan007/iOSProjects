//
//  LoginViewController.swift
//  LoginDataPassing
//
//  Created by Danish Pathan on 21/02/19.
//  Copyright © 2019 Danish Pathan. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
   var name = String()
   var emailid = String()
   var phoneNumber = String()
   var password = String()
   var retypePassword = String()
    var checkEmail = String()
    var checkPassword = String()
   
    @IBOutlet weak var loginEmail: UITextField!
    @IBOutlet weak var loginPassword: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
     checkEmail = emailid
     checkPassword = password
    }
    
    @IBAction func loginClicked(_ sender: UIButton) {
        let login = loginEmail.text!
        let passwd = loginPassword.text!
        if emailid == login    && password == passwd{
            self.performSegue(withIdentifier: "dataPassProfile", sender: nil)
        }
        
        
        
    }
    
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is ProfileViewController{
            let profileViewController = segue.destination as? ProfileViewController
            profileViewController?.profileName = name
            profileViewController?.profileEmailid = emailid
            profileViewController?.profilePhoneNumber = phoneNumber
            profileViewController?.profilePassword = password
            profileViewController?.profileRetypePassword = retypePassword
        }
    }
    
    
    
    
    
    
    
    
    
    
    
//    {
//
//    if let controllers = self.navigationController?.viewControllers{
//    for controller in controllers{
//    print(controllers)
//    if let profileViewController = controller as? ProfileViewController{
//
//    profileViewController.profileName = name
//    profileViewController.profileEmailid = emailid
//    profileViewController.profilePhoneNumber = phoneNumber
//    profileViewController.profilePassword = password
//    profileViewController.profileRetypePassword = retypePassword
//
//    self.navigationController?.pushViewController(profileViewController, animated: true)
//    break
//    }
//
//
//    }
//
//    }
//
//    }
    
  

}

//
//  UserDetails.swift
//  GoogleSignDemo
//
//  Created by Zap.Danish on 24/04/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import Foundation

class UserData:NSObject{
    static var shared = UserData()
    var userId:String = String()
    var userName:String = String()
    var userEmail:String = String()
    var imageUrl:URL!
}


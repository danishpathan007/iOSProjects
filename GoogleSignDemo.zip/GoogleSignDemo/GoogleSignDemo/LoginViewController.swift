//
//  LoginViewController.swift
//  GoogleSignDemo
//
//  Created by Zap.Danish on 24/04/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit
import GoogleSignIn

class LoginViewController: UIViewController {

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profileImageView.layer.borderWidth = 1.0
        profileImageView.layer.borderColor = UIColor.yellow.cgColor
        nameLabel.text = "Welcome Mr.\(UserData.shared.userName)"
        emailLabel.text = "\(UserData.shared.userEmail)"
        profileImageView.kf.setImage(with: UserData.shared.imageUrl)
    }
    

    @IBAction func logoutButtonTapped(_ sender: UIButton) {
        
        GIDSignIn.sharedInstance().signOut()
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "MainViewController")
        self.present(controller, animated: true, completion: nil)
    
        
    }
    
}

//
//  ViewController.swift
//  GoogleSignDemo
//
//  Created by Zap.Danish on 24/04/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit
import GoogleSignIn
import Kingfisher
import TYTumblrHUD

class ViewController: UIViewController,GIDSignInUIDelegate,GIDSignInDelegate {
  
   @IBOutlet weak var signInButton: GIDSignInButton!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
    //TYTumblrHUD.showAdded(to: self.view, animated: true)
    //MARK:- GIDDelegate
    GIDSignIn.sharedInstance().uiDelegate = self
    GIDSignIn.sharedInstance()?.delegate = self
    
      /*MARK:- SigninButton
       let signinButton = GIDSignInButton(frame:CGRect(x: 0, y: 0, width: 350, height: 45))
            signinButton.center = view.center
            signInButton.style = .wide
            view.addSubview(signinButton)
      */
    
    }
    
  
   // var transform: CGFloat = 0
    @IBAction func signInButtonTapped(_ sender: UIButton) {
        GIDSignIn.sharedInstance()?.signIn()
       /* transform += 90
        UIView.animate(withDuration: 2.0) {
            let _transform = CGAffineTransform(rotationAngle: self.transform)
            self.signInButton.transform = _transform.scaledBy(x: 1.5, y: 1.5)
            }
        */
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        
        if let error = error {
            print("\(error.localizedDescription)")
        }else{
            let userId = user.userID
            //let idToken = user.authentication.idToken
            let email = user.profile.email
            let fullName = user.profile.name
            //let givenName = user.profile.givenName
            //let familyName = user.profile.familyName
            UserData.shared.userId = userId!
            UserData.shared.userEmail = email!
            UserData.shared.userName = fullName!
            if user.profile.hasImage
            {
                let imageUrl = user.profile.imageURL(withDimension: 600)
                UserData.shared.imageUrl = imageUrl
            }
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "LoginViewController")
            self.present(controller, animated: true, completion: nil)
            }
    }
}


//
//  ViewController.swift
//  TableViewCollectionView
//
//  Created by Zap.Danish on 15/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    @IBOutlet weak var tableView: UITableView!
    
    var heightForImageCell:[(CGFloat,Int)] = [(200.0,1),(200.0,1),(300.0,2),(200.0,0)]
    var width: [CGFloat] = [1.0,2.5,2.5,3.0]
    
  
    var sectionTitle:[String] = ["Trending","Favourites","New Releases"]
    override func viewDidLoad() {
        super.viewDidLoad()
      tableView.dataSource = self
      tableView.delegate = self
   
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
        let vc = tableView.dequeueReusableCell(withIdentifier: "reusedCell") as! TableViewCell
        vc.width = width[indexPath.row]
        vc.heightForImageCell = heightForImageCell[indexPath.row]
        vc.sectionTitle.text = sectionTitle[indexPath.row%sectionTitle.count]
        return vc
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return (heightForImageCell[indexPath.row].0 + 30.0)
    }
}


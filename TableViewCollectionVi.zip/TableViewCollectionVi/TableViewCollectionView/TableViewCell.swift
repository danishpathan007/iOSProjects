//
//  TableViewCell.swift
//  TableViewCollectionView
//
//  Created by Zap.Danish on 15/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell,UICollectionViewDataSource,UICollectionViewDelegate,
UICollectionViewDelegateFlowLayout {
  
    @IBOutlet weak var imageCollectionView: UICollectionView!
    
    
    @IBOutlet weak var sectionTitle: UILabel!
    var imageName:[String] = ["ar rehman","b praak","arijit singh","sukhbinder"]
    var imageArray:[UIImage] = [#imageLiteral(resourceName: "ar rehman"),#imageLiteral(resourceName: "b praak"),#imageLiteral(resourceName: "arijit singh"),#imageLiteral(resourceName: "sukhbinder")]

    
    var width: CGFloat = 100.0
    var heightForImageCell:(CGFloat,Int) = (300.0,1)
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imageCollectionView.dataSource = self
        imageCollectionView.delegate = self
        
        imageCollectionView.register(UINib(nibName: "ImageCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "imageReused")
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      return 9
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cv = collectionView.dequeueReusableCell(withReuseIdentifier: "imageReused", for: indexPath) as! ImageCollectionViewCell
            cv.imageView.image = imageArray[indexPath.row%imageArray.count]
            cv.imageName.text = imageName[indexPath.row%imageName.count]
        
        if heightForImageCell.1 == 0 {
            cv.imageView.frame.size = CGSize(width: heightForImageCell.0 - 30, height: heightForImageCell.0 - 30.0)
        }
       
        return cv
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if heightForImageCell.1 == 0{
                        return CGSize(width: heightForImageCell.0,
                          height: heightForImageCell.0)
        }else{
        let height = (heightForImageCell.0) / CGFloat(heightForImageCell.1)
        return CGSize(width: collectionView.frame.size.width/width,
                      height: height)
    }
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let cv = cell as! ImageCollectionViewCell
        if heightForImageCell.1 == 0{
            //print(cv.imageView.frame.size)
            cv.imageView.layer.cornerRadius = cv.imageView.frame.size.height/2.0
        }
    }
    

}

//
//  CollectionViewCell.swift
//  TableViewCollectionView
//
//  Created by Zap.Danish on 15/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

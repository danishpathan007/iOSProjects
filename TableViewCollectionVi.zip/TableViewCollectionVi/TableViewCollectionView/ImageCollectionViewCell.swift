//
//  ImageCollectionViewCell.swift
//  TableViewCollectionView
//
//  Created by Zap.Danish on 15/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
   
    @IBOutlet weak var constarint: NSLayoutConstraint!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var imageName: UILabel!
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imageView.clipsToBounds = true
    }

}

//
//  ViewController.swift
//  EMI calclator
//
//  Created by Zap.Danish on 04/06/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var loanAmountTextField: UITextField!
    @IBOutlet weak var loanInterestTextField: UITextField!
    @IBOutlet weak var loanPeriodTextField: UITextField!
    @IBOutlet weak var calculateEMIButton: UIButton!
    
    
    @IBOutlet weak var totalPaymentLabel: UILabel!
    @IBOutlet weak var monthlyEMILabel: UILabel!
    @IBOutlet weak var totalInterestPaymentLabel: UILabel!
    
    var  loanAmount:Double = 0.0
    var  interestRate:Double = 0.0
    var  loanPeriodInMonths:Double = 0.0
    var  emi:Double = 0.0
    var  totalEmiPayment:Double = 0.0
    var  totalInterestPayment:Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    
    @IBAction func calculateEMiButtonTapped(_ sender:UIButton){
        
        loanAmount = Double(loanAmountTextField.text!) ?? 0.0
        interestRate = Double(loanInterestTextField.text!) ?? 0.0
        loanPeriodInMonths = Double(loanPeriodTextField.text!) ?? 0.0
        
        
        let intersetRateInMonths = interestRate / (12 * 100)
        emi = (loanAmount * intersetRateInMonths * pow(1 + intersetRateInMonths, loanPeriodInMonths)) / (pow(1+intersetRateInMonths, loanPeriodInMonths) - 1)
        print(emi)
        
        totalEmiPayment = emi * loanPeriodInMonths
        
        totalInterestPayment = totalEmiPayment - loanAmount
        
        monthlyEMILabel.text! = String.localizedStringWithFormat("%.2f", emi)
        totalInterestPaymentLabel.text! = String.localizedStringWithFormat("%.2f", totalInterestPayment)
        totalPaymentLabel.text! = String.localizedStringWithFormat("%.2f", totalEmiPayment)
        
        
    }
    
    @IBAction func clearButtontapped(_ sender: UIButton) {
        loanAmountTextField.text! = ""
        loanInterestTextField.text! = ""
        loanPeriodTextField.text! = ""
        monthlyEMILabel.text! = ""
        totalInterestPaymentLabel.text! = ""
        totalPaymentLabel.text! = ""
    }
    

}


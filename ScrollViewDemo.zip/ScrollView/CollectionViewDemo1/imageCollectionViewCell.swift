//
//  imageCollectionViewCell.swift
//  CollectionViewDemo1
//
//  Created by Zap.Danish on 13/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class imageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var images: UIImageView!
    
   
}

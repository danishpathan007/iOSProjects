//
//  ViewController.swift
//  CollectionViewDemo1
//
//  Created by Zap.Danish on 13/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UICollectionViewDelegate {
  
    @IBOutlet weak var pageControl: UIPageControl!
    let imagesArray:[UIImage] = [#imageLiteral(resourceName: "sallu"),#imageLiteral(resourceName: "light"),#imageLiteral(resourceName: "vegetable"),#imageLiteral(resourceName: "grapes")]
 
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var prevButton: UIButton!
    @IBOutlet weak var imagesCollectionView: UICollectionView!
    
    var counter:Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
      imagesCollectionView.dataSource = self
        imagesCollectionView.delegate = self
        pageControl.numberOfPages = imagesArray.count
      startTimer()
    }

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagesArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let imageVc = imagesCollectionView.dequeueReusableCell(withReuseIdentifier: "image", for: indexPath) as! imageCollectionViewCell
        imageVc.images.image = imagesArray[indexPath.row]
        return imageVc
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: imagesCollectionView.frame.width, height: imagesCollectionView.frame.height / 1.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        guard imagesCollectionView.visibleCells.count > 0 else {return}
        
        let cell = imagesCollectionView.visibleCells[0] as! imageCollectionViewCell
        guard let indexPath = imagesCollectionView.indexPath(for: cell)
            else
        {
            return
            
        }
        self.pageControl.currentPage = indexPath.row
    }
    
    @IBAction func prevButtonClicked(_ sender: UIButton) {
        if pageControl.currentPage == 0{
            pageControl.currentPage = 0
        }
        else {
            let indexPath = IndexPath(row: pageControl.currentPage-1, section: 0)
            imagesCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
            pageControl.currentPage = pageControl.currentPage - 1
        }
        
        print(pageControl.currentPage)
        print(imagesArray.count)
     
    }
    
    @IBAction func nextButtonClicked(_ sender: Any) {
        if pageControl.currentPage == imagesArray.count-1{
           pageControl.currentPage = imagesArray.count-1
        }else{
            let indexPath = IndexPath(row: pageControl.currentPage+1, section: 0)
            imagesCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
            pageControl.currentPage = pageControl.currentPage + 1
        print(pageControl.currentPage)
           
        }
        
    }
    
    
    
    func startTimer() {
        
        _ =  Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.scrollAutomatically), userInfo: nil, repeats: true)
    }
    
    
    @objc func scrollAutomatically(_ timer1: Timer) {
        if counter < imagesArray.count{
            let index = IndexPath(item: counter, section: 0)
            self.imagesCollectionView.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
            pageControl.currentPage = counter
            counter += 1
        }else{
            counter = 0
            let index = IndexPath(item: counter, section: 0)
            self.imagesCollectionView.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
            pageControl.currentPage = counter
            counter = 1
        }
     
    }
    
}


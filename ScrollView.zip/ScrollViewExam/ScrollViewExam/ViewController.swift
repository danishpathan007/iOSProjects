//
//  ViewController.swift
//  ScrollViewExam
//
//  Created by Danish Pathan on 13/02/19.
//  Copyright © 2019 Danish Pathan. All rights reserved.
//

import UIKit

class ViewController: UIViewController{

    @IBOutlet weak var scrollViewOutlet: UIScrollView!
        
        
        
        //MARK:- StudentDeatails Array
        
        var names:[String] = ["Danish Khan","Ali Raza","ravi saini","ajay kumar","vijay kumar","shyam","manoj","ravish","vinay"]
        
        var roll:[String] = ["D 101","D 102","O 103","C 104","D 105","O 106","D 107","C 108","D 109","C 110"]
        
        var dept:[String] = ["iOs","Android","java","c","php","bootstrap","css","UX Design","manager","bar tender"]
    
  
    var yPosition:CGFloat = 0
    var scrollViewContentSize:CGFloat=0
        
        //var frame = CGRect(x: 0, y: 0, width: 0, height: 0)
        
        override func viewDidLoad() {
            
            super.viewDidLoad()
            
            //scrollViewOutlet.isHidden = true
            let studentViewWidth:CGFloat = scrollViewOutlet.frame.width
            let studentViewHeight:CGFloat = 120
            
            for index in 0..<names.count{
                
                
                let nameLabel = UILabel(frame: CGRect(x: 0, y: 0, width: studentViewWidth, height: 30))
                
                nameLabel.backgroundColor = UIColor.lightText
                nameLabel.textColor = UIColor.blue
                nameLabel.font = .boldSystemFont(ofSize: 18)
                
                let rollnoLabel = UILabel(frame: CGRect(x: 0, y: 40, width: studentViewWidth, height: 30))
               
                
                let deptLabel = UILabel(frame: CGRect(x: 0, y: 80, width: studentViewWidth, height: 30))
                
               
                
                nameLabel.text = names[index]
                
                rollnoLabel.text = roll[index]
                
                deptLabel.text = dept[index]
                
                let StudentView = UIView()
                StudentView.frame.size.width = studentViewWidth
                StudentView.frame.size.height = studentViewHeight
                StudentView.center = self.view.center
                StudentView.frame.origin.y = yPosition
                StudentView.backgroundColor = UIColor.cyan
                self.scrollViewOutlet.addSubview(StudentView)
                StudentView.addSubview(nameLabel)
                StudentView.addSubview(rollnoLabel)
                StudentView.addSubview(deptLabel)
                
                let spacer:CGFloat = 10
                yPosition += studentViewHeight + spacer
                scrollViewContentSize += studentViewHeight + spacer
                
                scrollViewOutlet.contentSize = CGSize(width:studentViewWidth , height: scrollViewContentSize )
            }
    }
        
    @IBAction func addStudendPressed(_ sender: UIButton) {
        
       scrollViewOutlet.isHidden = false
    }
    
     
    
}





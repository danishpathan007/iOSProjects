//
//  ViewController.swift
//  UiControllerStepperSliderSwitch
//
//  Created by Danish Pathan on 13/02/19.
//  Copyright © 2019 Danish Pathan. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    
    //MARK:- Outlets
    @IBOutlet weak var citizanSwitch: UISwitch!
    @IBOutlet weak var currencySegmentOutlet: UISegmentedControl!
    @IBOutlet weak var principalOutlet: UITextField!
    @IBOutlet weak var sliderOutlet: UISlider!
    @IBOutlet weak var stepperOutlet: UIStepper!
    @IBOutlet weak var displayAmountLabel: UILabel!
    @IBOutlet weak var showTimeLableOutlet: UILabel!
    @IBOutlet weak var displayRateValueOutlet: UILabel!
   
    //MARK:- var
    var princpal:Double = 0.0
    var time:Double = 1.0
    var rate:Double = 5.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showTimeLableOutlet.text = "1"
        displayRateValueOutlet.text = "5%"
        principalOutlet.delegate = self
        currencySegmentOutlet.isEnabled = false
        sliderOutlet.isEnabled = false
        stepperOutlet.isEnabled = false
        citizanSwitch.isEnabled = false
    }
    
    
    //MARK:- TextField delegate
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let text = (principalOutlet.text! as NSString).replacingCharacters(in: range, with: string)
        if text.isEmpty{
            currencySegmentOutlet.isEnabled = false
            sliderOutlet.isEnabled = false
            stepperOutlet.isEnabled = false
            citizanSwitch.isEnabled = false
        }else{
            currencySegmentOutlet.isEnabled = true
            sliderOutlet.isEnabled = true
            stepperOutlet.isEnabled = true
            citizanSwitch.isEnabled = true
        }
        return true
    }

    //MARK:- Segment
    @IBAction func CurrencySegmentClicked(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            displayAmountLabel.text = "₹\(calculatePrincipal())"
        case 1:
            var final = calculatePrincipal()
            final /= 70.88
            displayAmountLabel.text = "$\(final)"
        case 2:
            var final = calculatePrincipal()
            final /= 80.02
            displayAmountLabel.text = "€\(final)"
        default:
            break
        }
    }
    
    //MARK:- Stepper

    @IBAction func timeStepperClicked(_ sender: UIStepper) {
        time = sender.value
        showTimeLableOutlet.text = "\(Int(time))"
        displayAmountLabel.text = "\(calculatePrincipal())"
    }
    
   
    //MARK:- Slider
    @IBAction func rateSliderClicked(_ sender: UISlider) {
        displayRateValueOutlet.text = "\(Int(sender.value))%"
        rate = Double(sender.value)
        displayAmountLabel.text = "\(calculatePrincipal())"
    }
    
    
    //MARK:- switch
    @IBAction func switchClicked(_ sender: UISwitch) {
        
        if sender.isOn{
             rate += 5
             displayAmountLabel.text = "\(calculatePrincipal())"
        }else{
              rate -= 5
              displayAmountLabel.text = "\(calculatePrincipal())"
        }
    }
    
    func calculatePrincipal()->Double{
        princpal = Double(principalOutlet.text!)!
        let finalAmt = princpal + (princpal * time * rate / 100)
        return finalAmt
    }
    

}


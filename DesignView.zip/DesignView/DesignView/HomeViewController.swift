//
// HomeViewController.swift
//  DesignView
//
//  Created by Zap.Danish on 25/02/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var logoutButton: UIButton!
    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var contactButton: UIButton!
    @IBOutlet weak var myOrderButton: UIButton!
    @IBOutlet weak var myContactButton: UIButton!
    @IBOutlet weak var profileButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        myProfileButtonModification()
        myContactButtonModification()
        myOrderButtonModification()
        contactButtonModification()
        settingButtonModification()
        logoutButtonModification()
       
}
    
    
    
    
    func myProfileButtonModification(){
        profileButton.layer.shadowColor = UIColor.black.cgColor
        profileButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        profileButton.layer.borderColor = UIColor.black.cgColor
        profileButton.layer.borderWidth = 1
        profileButton.layer.borderColor = UIColor.black.cgColor
        profileButton.layer.shadowRadius = 5
        profileButton.layer.shadowOpacity = 1.0
        
    }
    
    
    func myContactButtonModification(){
        myContactButton.layer.shadowColor = UIColor.black.cgColor
        myContactButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        myContactButton.layer.borderColor = UIColor.black.cgColor
        myContactButton.layer.borderWidth = 1
        myContactButton.layer.borderColor = UIColor.black.cgColor
        myContactButton.layer.shadowRadius = 5
        myContactButton.layer.shadowOpacity = 1.0
    }
    
    func myOrderButtonModification(){
        myOrderButton.layer.shadowColor = UIColor.black.cgColor
        myOrderButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        myOrderButton.layer.borderColor = UIColor.black.cgColor
        myOrderButton.layer.borderWidth = 1
        myOrderButton.layer.borderColor = UIColor.black.cgColor
        myOrderButton.layer.shadowRadius = 5
        myOrderButton.layer.shadowOpacity = 1.0
    }
    
    func contactButtonModification(){
        contactButton.layer.shadowColor = UIColor.black.cgColor
        contactButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        contactButton.layer.borderColor = UIColor.black.cgColor
        contactButton.layer.borderWidth = 1
        contactButton.layer.borderColor = UIColor.black.cgColor
        contactButton.layer.shadowRadius = 5
        contactButton.layer.shadowOpacity = 1.0
    }
    
    func settingButtonModification(){
        settingButton.layer.shadowColor = UIColor.black.cgColor
        settingButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        settingButton.layer.borderColor = UIColor.black.cgColor
        settingButton.layer.borderWidth = 1
        settingButton.layer.borderColor = UIColor.black.cgColor
        settingButton.layer.shadowRadius = 5
        settingButton.layer.shadowOpacity = 1.0
    }
    
    func logoutButtonModification(){
        logoutButton.layer.shadowColor = UIColor.black.cgColor
        logoutButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        logoutButton.layer.borderColor = UIColor.black.cgColor
        logoutButton.layer.borderWidth = 1
        logoutButton.layer.borderColor = UIColor.black.cgColor
        logoutButton.layer.shadowRadius = 5
        logoutButton.layer.shadowOpacity = 1.0
    }

    
    @IBAction func logoutButtonClicked(_ sender: UIButton) {
        
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
        
    }

}


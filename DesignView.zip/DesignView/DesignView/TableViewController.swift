//
//  TableViewController.swift
//  DesignView
//
//  Created by Zap.Danish on 03/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class TableViewController: UIViewController , UITableViewDataSource,UITableViewDelegate{
  
    @IBOutlet weak var infoTable: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       infoTable.delegate = self
    infoTable.dataSource = self
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
    return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 150
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//         let cellView:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        
//        if ((infoTable?.indexPathForSelectedRow) != nil) {
//            cellView.timeView.backgroundColor = UIColor.blue
//
//        }
//        else{
//            cellView.timeView.backgroundColor = UIColor.blue
//        }
//
//  if indexPath == [1,0]{
//    cellView.backgroudView.backgroundColor = UIColor.white
//
//    cellView.timeView.backgroundColor = UIColor.blue
//                        print(indexPath.row)
//        }
//        else{
//           cellView.timeView.backgroundColor = UIColor.blue
//
//        }
       
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.displayTimeLable?.text = "12:22"
        return cell
    }
    


}

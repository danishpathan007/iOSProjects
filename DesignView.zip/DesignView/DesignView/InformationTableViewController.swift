//
//  InformationTableViewController.swift
//  DesignView
//
//  Created by Zap.Danish on 03/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class InformationTableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    
    @IBOutlet weak var infoTableView: UITableView!
    
    let timeArray:[String] = ["12:00 AM","1:00 AM","2:00 AM","3:00 AM","4:00 AM","5:00 AM"]
    
    let amountArray:[String] = ["$10","$12","$15","$11","$20","$22"]
    
    var count:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        infoTableView.dataSource = self
        infoTableView.delegate = self

    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return timeArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let reusedcell:InformationTableViewCell = tableView.dequeueReusableCell(withIdentifier: "reusedcell") as! InformationTableViewCell
        
        reusedcell.timeLabel.text = timeArray[indexPath.row]
        reusedcell.amountLabel.text = amountArray[indexPath.row]
        reusedcell.backView.backgroundColor = UIColor.purple
        

        if count == 0{
            reusedcell.backView.backgroundColor = UIColor.blue
        }else if count == 1{
             reusedcell.backView.backgroundColor = UIColor.red
        }else if count == 2{
            reusedcell.backView.backgroundColor = UIColor.yellow
        }else if count == 3{
            reusedcell.backView.backgroundColor = UIColor.purple
        }else if count == 4{
            reusedcell.backView.backgroundColor = UIColor.lightGray
        }else if count == 5{
            reusedcell.backView.backgroundColor = UIColor.green
            
        }
        count += 1
        return reusedcell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        

        
      
        let cell:InformationTableViewCell = tableView.cellForRow(at: indexPath) as! UITableViewCell as! InformationTableViewCell
        cell.leftView.backgroundColor = UIColor.purple
        cell.backView.backgroundColor = UIColor.purple
        cell.rightView.backgroundColor = UIColor.white
    }
    
    
  
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {

        tableView.cellForRow(at: indexPath as IndexPath)?.backgroundColor = UIColor.clear
        
    }

}

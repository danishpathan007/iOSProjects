//
//  TableViewCell.swift
//  DesignView
//
//  Created by Zap.Danish on 03/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

   
    @IBOutlet weak var displayTimeLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}

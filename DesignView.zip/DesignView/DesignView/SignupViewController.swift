//
//  SignupViewController.swift
//  DesignView
//
//  Created by Zap.Danish on 27/02/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {

    @IBOutlet weak var signupButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func signupButtonClicked(_ sender: UIButton) {
        performSegue(withIdentifier: "signupSucess", sender: nil)
        
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}

//
//  InformationTableViewCell.swift
//  DesignView
//
//  Created by Zap.Danish on 03/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class InformationTableViewCell: UITableViewCell {

    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var leftView: UIView!
    @IBOutlet weak var rightView: UIView!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var startingAddress: UILabel!
    @IBOutlet weak var endingAddress: UILabel!
    @IBOutlet weak var weatherCondition: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    

}

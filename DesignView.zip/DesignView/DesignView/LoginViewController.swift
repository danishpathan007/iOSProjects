//
//  LoginViewController.swift
//  DesignView
//
//  Created by Zap.Danish on 27/02/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        loginButton.layer.shadowColor = UIColor.black.cgColor
        loginButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        loginButton.layer.borderColor = UIColor.black.cgColor
        loginButton.layer.borderWidth = 1
        loginButton.layer.borderColor = UIColor.black.cgColor
        loginButton.layer.shadowRadius = 5
        loginButton.layer.shadowOpacity = 1.0
        
//        userNameTextField.layer.shadowColor = UIColor.black.cgColor
//        userNameTextField.layer.shadowOffset = CGSize(width: 5, height: 5)
      
//        userNameTextField.layer.shadowRadius = 5
//        userNameTextField.layer.shadowOpacity = 1.0
        userNameTextField.layer.borderColor = UIColor.black.cgColor
        userNameTextField.layer.borderWidth = 1
        
        passwordTextField.layer.borderColor = UIColor.black.cgColor
        passwordTextField.layer.borderWidth = 1
        
        
        
        
    }
    
    @IBAction func loginButtonClicked(_ sender: UIButton) {
        if userNameTextField.text == "danish007" && passwordTextField.text == "1234"{
        performSegue(withIdentifier: "loginSuccess", sender: nil)
        }
    }
    
    
    @IBAction func signUpSuccess(segue: UIStoryboardSegue) {
        
    }
   

}

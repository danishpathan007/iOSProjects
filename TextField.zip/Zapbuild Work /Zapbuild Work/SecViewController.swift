//
//  SecViewController.swift
//  Zapbuild Work
//
//  Created by Danish Pathan on 06/02/19.
//  Copyright © 2019 Danish Pathan. All rights reserved.
//

import UIKit

class SecViewController: UIViewController {
    @IBOutlet weak var secTextView: UITextView!
    
    @IBOutlet weak var fontSizeOutlet: UILabel!
    @IBOutlet weak var sliderOutlet: UISlider!
    var data = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        if data.isEmpty{
          secTextView.text = "Data not exist. go back and add somthing! thankyou "
        }else{
            secTextView.text = data
        }
    }
    

    @IBAction func zoomSlider(_ sender: UISlider) {
        
        let senderValue = CGFloat(sender.value)
        secTextView?.font = UIFont(name: (secTextView?.font?.fontName)!, size: senderValue * 10)
       // secTextView?.sizeToFit()
    }
    
    @IBAction func switchButton(_ sender: UISwitch) {
        if !sender.isOn{
           secTextView.isHidden = true
            fontSizeOutlet.isHidden = true
            sliderOutlet.isHidden = true
        }else{
        secTextView.isHidden = false
        fontSizeOutlet.isHidden = false
        sliderOutlet.isHidden = false
        }
    }
    
    
    
    
}

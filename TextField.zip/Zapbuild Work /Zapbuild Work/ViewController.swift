//
//  ViewController.swift
//  Zapbuild Work
//
//  Created by Danish Pathan on 05/02/19.
//  Copyright © 2019 Danish Pathan. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    //MARK:- Outlet
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var showMessage: UILabel!
    @IBOutlet weak var showAllMessages: UITextView!
    @IBOutlet weak var submitButton: UIButton!
    
    //MARK:- ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
    submitButton.isEnabled = false
    }
  
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //submitButton.isEnabled = true
    }
    
    //MARK:- TextField Delegate
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
       
        let text = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        
        if !text.isEmpty{
            submitButton.isEnabled = true
        }else{
            submitButton.isEnabled = false
        }
        return true
    }
    
    //MARK:- Submit Button
    
    @IBAction func submit(_ sender: Any) {
        
        guard textField.text != "" else{
           showMessage.isHidden = true
            return
        }
        showMessage.isHidden = false
        showMessage.text = textField.text
        showAllMessages.text.append("\(textField.text!)\n")
        textField.text = ""
        submitButton.isEnabled = false
      }
    
    //MARK:- Data Passing
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is SecViewController{
            let vc = segue.destination as? SecViewController
            vc?.data = showAllMessages.text!
        }
    }
    
    // MARK:- Segment Activity
    @IBAction func themeChangeSegment(_ sender: UISegmentedControl) {
        
        switch (sender.selectedSegmentIndex)
        {
        case 0:
            view.backgroundColor = UIColor.red
            
        case 1:
            view.backgroundColor = UIColor.green
        case 2:
            view.backgroundColor = UIColor.yellow
        case 3:
            view.backgroundColor = UIColor.cyan
        default:
            break
            
        }
        
    }
    
    //MARK:- Clear Button
    
    @IBAction func clearPressed(_ sender: Any) {
        showAllMessages.text = ""
    }
}


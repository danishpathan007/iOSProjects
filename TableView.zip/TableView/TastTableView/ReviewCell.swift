//
//  ReviewCell.swift
//  TastTableView
//
//  Created by Zap.Danish on 06/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class ReviewCell: UITableViewCell {

    @IBOutlet weak var reviewLabel: UILabel!
    @IBOutlet weak var starLabel: UILabel!
    @IBOutlet weak var reviewImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
      
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

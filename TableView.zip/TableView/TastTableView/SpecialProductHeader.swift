//
//  SpecialProductHeader.swift
//  TastTableView
//
//  Created by Zap.Danish on 05/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class SpecialProductHeader: UITableViewHeaderFooterView {


    @IBOutlet weak var headerLabel: UILabel!
    
}

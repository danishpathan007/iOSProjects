//
//  ViewController.swift
//  TastTableView
//
//  Created by Zap.Danish on 05/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
   
    var imgArray = [#imageLiteral(resourceName: "banana")]
   
    var specialProductName:[String] = ["Apple","Bana","mango","graps"]
    let specialProductPrice:[String] = ["Rs.110","Rs.60","Rs.120","Rs.220"]
    let specialProductDiscountPrice:[String] = ["Rs.90","Rs.45","Rs.90","Rs.190"]
    let specialPrductImage:[String] = ["apple-1","banana","mango","grapes"]

    @IBOutlet weak var menuTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    menuTableView.dataSource = self
    menuTableView.delegate = self
    
       
        
        
        // MARK:- Nib register
        
        menuTableView.register(UINib(nibName: "SpecialProductCell", bundle: nil), forCellReuseIdentifier: "specialProduct")
        
        menuTableView.register(UINib(nibName: "PreviousPurchaseCell",bundle: nil), forCellReuseIdentifier: "PreviousPurchaseCell" )
        
        
        menuTableView.register(UINib(nibName: "ReviewCell", bundle: nil), forCellReuseIdentifier: "ReviewCell")
        
        menuTableView.register(UINib(nibName: "ClothsCell", bundle: nil), forCellReuseIdentifier: "ClothsCell")
        
        menuTableView.register(UINib(nibName: "LogoutCell", bundle: nil), forCellReuseIdentifier: "LogoutCell")
      
        // MARK:- HeaderFooterRegister
        
        let headernib = UINib.init(nibName:"SpecialProductHeader",bundle: nil)
        menuTableView.register(headernib, forHeaderFooterViewReuseIdentifier: "SpecialProductHeader")
        
        let footernib = UINib.init(nibName: "FooterView",bundle:nil)
        menuTableView.register(footernib, forHeaderFooterViewReuseIdentifier: "FooterCell")
        
    }
    
    
   
    
    
    
    //MARK:- numberOfSection
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 6
    }
    
    //MARK:- numberOfRowsInSection
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
          return imgArray.count
        }
        if section == 1{
          return specialProductName.count
        }
        if section == 2{
            return 3
        }
        if section == 3{
            return 2
        }
        if section == 4{
            return 2
        }
        return 1
    }
    
    //MARK:- heightForRowAt
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
//        if indexPath.section == 2{
//            return 80
//        }
//        if indexPath.section == 3{
//            return  UITableView.automaticDimension
//        }
//        if indexPath.section == 4{
//            return 80
//        }
//        if indexPath.section == 5{
//            return 80
//        }
        return UITableView.automaticDimension
    }
    
    //MARK:- cellForRowAt
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0{
        let cell:imageCell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! imageCell
        return cell
        }
        
        if indexPath.section == 1{
            let specialPcell:SpecialProductCell = menuTableView.dequeueReusableCell(withIdentifier: "specialProduct") as! SpecialProductCell
        specialPcell.specialProductName.text = specialProductName[indexPath.row%specialProductName.count]
        specialPcell.specialProductPrice.text = specialProductPrice[indexPath.row%specialProductPrice.count]
        specialPcell.specialPrductDiscountPrice.text = specialProductDiscountPrice[indexPath.row%specialProductDiscountPrice.count]
        specialPcell.specialProductImageview.image = UIImage(named: specialPrductImage[indexPath.row%specialPrductImage.count])
            
        return specialPcell
        }
        if indexPath.section == 2{
            let previousPurchase:PreviousPurchaseCell = menuTableView.dequeueReusableCell(withIdentifier: "PreviousPurchaseCell") as! PreviousPurchaseCell
            
            return previousPurchase
        }
        if indexPath.section == 3{
            let review:ReviewCell = menuTableView.dequeueReusableCell(withIdentifier: "ReviewCell") as! ReviewCell
            review.starLabel.text = "* * * *"
            review.reviewLabel.text = "jhsfhdkajfgkhjsdgkjhsdjhfdsgfjhgsdfhjjsdfjgfhjgfjgjsd"
            return review
        }
        if indexPath.section == 4{
        let cloths:ClothsCell = menuTableView.dequeueReusableCell(withIdentifier: "ClothsCell") as! ClothsCell
        return cloths
        }
        let logout:LogoutCell = menuTableView.dequeueReusableCell(withIdentifier: "LogoutCell") as! LogoutCell
        return logout
  }
    
   
  
   
    
    //MARK:- viewForHeaderInSection
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        
        if section == 1{
            let header:SpecialProductHeader = menuTableView.dequeueReusableHeaderFooterView(withIdentifier: "SpecialProductHeader") as! SpecialProductHeader
         header.headerLabel.text = "Special Products For You"
        return header
        }
        if section == 2{
            let header:SpecialProductHeader = menuTableView.dequeueReusableHeaderFooterView(withIdentifier: "SpecialProductHeader") as! SpecialProductHeader
            header.headerLabel.text = "Previous Purchase"
            return header
        }
        if section == 3{
            let header:SpecialProductHeader = menuTableView.dequeueReusableHeaderFooterView(withIdentifier: "SpecialProductHeader") as! SpecialProductHeader
            header.headerLabel.text = "Review"
            return header
        }
        if section == 4{
            let header:SpecialProductHeader = menuTableView.dequeueReusableHeaderFooterView(withIdentifier: "SpecialProductHeader") as! SpecialProductHeader
            header.headerLabel.text = "Cloths"
            return header
        }
        
        return nil
        
    }
    
    
    //MARK:- viewForFooterInSection

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if section == 1{
            let footerCell:FooterView = menuTableView.dequeueReusableHeaderFooterView(withIdentifier: "FooterCell") as! FooterView
            return footerCell
        }

        if section == 2{
            let footerCell:FooterView = menuTableView.dequeueReusableHeaderFooterView(withIdentifier: "FooterCell") as! FooterView

            return footerCell
        }
        if section == 3{
            let footerCell:FooterView = menuTableView.dequeueReusableHeaderFooterView(withIdentifier: "FooterCell") as! FooterView
            
            return footerCell
        }
        if section == 4{
            let footerCell:FooterView = menuTableView.dequeueReusableHeaderFooterView(withIdentifier: "FooterCell") as! FooterView
            
            return footerCell
        }
        
        return nil
    }

    //MARK:- heightForHeaderAndFooterInSection
    
  
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return 45
        }
        if section == 2{
            return 45
        }
        if section == 3{
            return 45
        }
        if section == 4{
            return 45
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 1{
            return 45
        }
        if section == 2{
            return 45
        }
        if section == 3{
            return 45
        }
        if section == 4{
            return 45
        }
        else{
            return 0
        }
    }
    
   
    
    //MARK:- CanEditRowAt
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if indexPath.section == 0{
             return true
        }
        if indexPath.section == 1{
             return true
        }
        return false
    }
    
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
    
        if  editingStyle == .delete{
            
            let alert = UIAlertController(title: "Want to delete?", message: "", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action) -> Void in
                if indexPath.section == 0 {
                    self.imgArray.remove(at: indexPath.row)
                }
                else if indexPath.section == 1 {
                    self.specialProductName.remove(at: indexPath.row)
                }
                
                tableView.deleteRows(at: [indexPath], with: .fade)
            }))
                
            alert.addAction(UIAlertAction(title: "No", style:  .cancel, handler: nil))
            
           self.present(alert,animated: true)
            
            
            }
        
        }
    
    
    
}



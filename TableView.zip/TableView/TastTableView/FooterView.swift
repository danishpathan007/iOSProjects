//
//  FooterView.swift
//  TastTableView
//
//  Created by Zap.Danish on 05/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class FooterView: UITableViewHeaderFooterView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}

//
//  SpecialProductCell.swift
//  TastTableView
//
//  Created by Zap.Danish on 05/03/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class SpecialProductCell: UITableViewCell {

    @IBOutlet weak var specialProductName: UILabel!
    
    @IBOutlet weak var specialProductPrice: UILabel!
    
    @IBOutlet weak var specialProductImageview: UIImageView!
    @IBOutlet weak var specialPrductDiscountPrice: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

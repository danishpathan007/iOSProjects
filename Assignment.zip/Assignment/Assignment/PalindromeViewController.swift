//
//  PalindromeViewController.swift
//  Assignment
//
//  Created by Zap.Danish on 02/05/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class PalindromeViewController: UIViewController {

    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var chechStringTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       playButton.clipsToBounds = true
       playButton.layer.cornerRadius = 30.0
    }
    
    
    //MARK:- PlayButton
    @IBAction func playButtonTapped(_ sender: UIButton) {
        
        if !chechStringTextField.text!.isEmpty{
        
        if isPalindrome(inputString: chechStringTextField.text!.lowercased()){
            let alert = UIAlertController(title: "Congratss!! Thanos Defeated", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Play Again", style: .default, handler: nil))
            self.present(alert,animated: true,completion: nil)
            
        }else{
            let alert = UIAlertController(title: "ohhh !! Jarvis", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Let's try again", style: .default, handler: nil))
            self.present(alert,animated: true,completion: nil)
        }
        }else{
            let alert = UIAlertController(title: "Please type anything", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alert,animated: true,completion: nil)

        }
 }
   
    
    //MARK:- Function to check the string is palindrome or not
    
    func isPalindrome(inputString: String) -> Bool {
        
        let stringLength = inputString.count
        
        var position = 0
        
        while position < stringLength / 2 {
            let startIndex = inputString.index(inputString.startIndex, offsetBy: position)
            let endIndex = inputString.index(inputString.endIndex, offsetBy: -position - 1)
            if inputString[startIndex] == inputString[endIndex] {
                position += 1
            } else {
                return false
            }
        }
        return true
    }
}

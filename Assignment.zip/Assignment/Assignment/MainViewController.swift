//
//  MainViewController.swift
//  Assignment
//
//  Created by Zap.Danish on 02/05/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    @IBOutlet weak var displayImageView: UIImageView!
    @IBOutlet weak var palindromeButton: UIButton!
    @IBOutlet weak var snakeGameButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        palindromeButton.layer.borderWidth = 1.0
        palindromeButton.layer.borderColor = UIColor.black.cgColor
        palindromeButton.layer.shadowRadius = 5
        palindromeButton.layer.shadowOpacity = 1.0
        palindromeButton.layer.shadowColor = UIColor.black.cgColor
        palindromeButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        snakeGameButton.layer.borderWidth = 1.0
        snakeGameButton.layer.borderColor = UIColor.black.cgColor
        snakeGameButton.layer.shadowRadius = 5
        snakeGameButton.layer.shadowOpacity = 1.0
        snakeGameButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        snakeGameButton.layer.shadowColor = UIColor.black.cgColor
        displayImageView.layer.borderWidth = 1.0
        displayImageView.layer.borderColor = UIColor.black.cgColor
      }


}


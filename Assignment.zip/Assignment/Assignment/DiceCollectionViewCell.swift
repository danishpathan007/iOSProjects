//
//  DiceCollectionViewCell.swift
//  Assignment
//
//  Created by Zap.Danish on 02/05/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit

class DiceCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var diceLabel: UILabel!
    @IBOutlet weak var laderJumpValueLabel: UILabel!
    
    @IBOutlet weak var diceImageView: UIImageView!
    

}

//
//  GameViewController.swift
//  Assignment
//
//  Created by Zap.Danish on 02/05/19.
//  Copyright © 2019 Zap.Danish. All rights reserved.
//

import UIKit
import AVFoundation


class GameViewController: UIViewController {
    //MARK:- Outlets
    @IBOutlet weak var diceRoleButton: UIButton!
    @IBOutlet weak var diceCollectionView: UICollectionView!
    @IBOutlet weak var diceValueImageView: UIImageView!
    @IBOutlet weak var playerStatusLabel: UILabel!
    //MARK:- variables
    var diceValues = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25]
    var diceRandomValue = 0
    var firstPlayerDiceValue = Int()
    var secondPlayerDiceValue = Int()
    var firstPlayerPosition = -1
    var secondPlayerPosition = -1
    var isFirstPlayer = true
    var diceMusicPlayer = AVAudioPlayer()
    var winMusicPlayer = AVAudioPlayer()
    let rollDiceSound = Bundle.main.path(forResource: "dice", ofType: ".mp3")
    let winSound = Bundle.main.path(forResource: "win", ofType: ".mp3")

    
    override func viewDidLoad() {
        super.viewDidLoad()
        setAudioPlayer()
        setButtonAndImageViewBorder()
        diceCollectionView.dataSource = self
        diceCollectionView.delegate = self
        diceValueImageView.isHidden = true
       
    }
    
    func setAudioPlayer(){
        do {
            diceMusicPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: rollDiceSound!))
            winMusicPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: winSound!))
        }catch{
            print(error)
        }
    }
    
    //MARK:- Button Modification
    func setButtonAndImageViewBorder(){
        diceValueImageView.layer.borderWidth = 1.0
        diceValueImageView.layer.borderColor = UIColor.black.cgColor
        diceValueImageView.layer.shadowRadius = 5
        diceValueImageView.layer.shadowOpacity = 1.0
        diceValueImageView.layer.shadowOffset = CGSize(width: 5, height: 5)
        diceValueImageView.layer.shadowColor = UIColor.black.cgColor
        diceRoleButton.layer.borderWidth = 1.0
        diceRoleButton.layer.borderColor = UIColor.black.cgColor
        diceRoleButton.layer.shadowRadius = 5
        diceRoleButton.layer.shadowOpacity = 1.0
        diceRoleButton.layer.shadowOffset = CGSize(width: 5, height: 5)
        diceRoleButton.layer.shadowColor = UIColor.black.cgColor
    }
   
    
    //MARK:- DiceRoleButton
    @IBAction func diceRoleTapped(_ sender: UIButton) {
        let randomDiceNumber = Int.random(in: 1...6)
        
        diceMusicPlayer.play()
        diceValueImageView.isHidden = false
        diceCollectionView.reloadData()
        
        switch randomDiceNumber {
        case 1:
            diceValueImageView.image = #imageLiteral(resourceName: "Dice1")
            diceRandomValue = 1
        case 2:
            diceValueImageView.image = #imageLiteral(resourceName: "Dice2")
            diceRandomValue =  2
        case 3:
            diceValueImageView.image = #imageLiteral(resourceName: "Dice 3")
            diceRandomValue =  3
        case 4:
            diceValueImageView.image = #imageLiteral(resourceName: "Dice4")
            diceRandomValue =  4
        case 5:
            diceValueImageView.image = #imageLiteral(resourceName: "Dice 5")
            diceRandomValue =  5
        case 6:
            diceValueImageView.image = #imageLiteral(resourceName: "Dice6")
            diceRandomValue =  6
        default:
            break
        }
        
        if isFirstPlayer{
            firstPlayerDiceValue = diceRandomValue
            playerStatusLabel.textColor = UIColor.blue
            playerStatusLabel.text = "1 🤾🏻‍♂️"
            changeFirstPlayerPosition()
            
        }else{
            secondPlayerDiceValue = diceRandomValue
            playerStatusLabel.textColor = UIColor.red
            playerStatusLabel.text = "2 🤾🏻‍♂️"
            changeSecondPlayerPosition()
        }
        
    }
    
    //MARK:- firstPlayerPosition
    func changeFirstPlayerPosition(){
        isFirstPlayer = false
       if firstPlayerPosition == -1{
            if firstPlayerDiceValue == 6{
                firstPlayerPosition += 1
                diceCollectionView.reloadData()
            }
        }else{
            firstPlayerPosition += firstPlayerDiceValue
            
            if firstPlayerPosition > 24{
                firstPlayerPosition -= firstPlayerDiceValue
                diceCollectionView.reloadData()
            }
            else if firstPlayerPosition == 14{
                firstPlayerPosition += 4
                diceCollectionView.reloadData()
            }
            else if firstPlayerPosition == 16{
                firstPlayerPosition -= 3
                diceCollectionView.reloadData()
            }
            else if firstPlayerPosition == 21{
                firstPlayerPosition += 1
            }else if firstPlayerPosition == 23{
                firstPlayerPosition -= 18
            }
            if firstPlayerPosition == 24{
                winMusicPlayer.play()
                let alert = UIAlertController(title: "Congratulations!!", message: "First Player Win", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Play again", style: .cancel, handler: {
                    action in self.winMusicPlayer.stop()
                }))
                self.present(alert,animated: true,completion: nil)
                firstPlayerPosition = -1
                secondPlayerPosition = -1
                diceValueImageView.isHidden = true
            }
        }
        print("1 \(firstPlayerDiceValue)")
        
    }
    
    
    //MARK:- secondPlayerPosition
    func changeSecondPlayerPosition(){
        isFirstPlayer = true
        if secondPlayerPosition == -1{
            if secondPlayerDiceValue == 6{
                secondPlayerPosition += 1
                diceCollectionView.reloadData()
            }
        }else{
            secondPlayerPosition += secondPlayerDiceValue
            
            if secondPlayerPosition > 24{
                secondPlayerPosition -= secondPlayerDiceValue
                diceCollectionView.reloadData()
            }
            else if secondPlayerPosition == 14{
                secondPlayerPosition += 4
                diceCollectionView.reloadData()
            }
            else if secondPlayerPosition == 16{
                secondPlayerPosition -= 3
                diceCollectionView.reloadData()
            }
            else if secondPlayerPosition == 21{
                secondPlayerPosition += 1
            }else if secondPlayerPosition == 23{
                secondPlayerPosition -= 18
            }
            if secondPlayerPosition == 24{
                winMusicPlayer.play()
                let alert = UIAlertController(title: "Congratulations!!", message: "Second Player Win", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Play again", style: .cancel, handler: {
                    action in self.winMusicPlayer.stop()
                }))
                self.present(alert,animated: true,completion: nil)
                secondPlayerPosition = -1
                firstPlayerPosition = -1
                diceValueImageView.isHidden = true
            }
        }
      print("2 \(secondPlayerDiceValue)")
        
    }
    
    
}



//MARK:- CollectionView Delegates
extension GameViewController:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
 

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return diceValues.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "reusedCell", for: indexPath) as! DiceCollectionViewCell
        cell.layer.borderWidth = 1.0
        cell.layer.borderColor = UIColor.black.cgColor
        cell.layer.shadowRadius = 5
        cell.layer.shadowOpacity = 1.0
        cell.layer.shadowOffset = CGSize(width: 5, height: 5)
        cell.layer.shadowColor = UIColor.black.cgColor
        
        cell.diceLabel.text = "\(diceValues[indexPath.row])"
        if indexPath.row == 0{
            cell.diceImageView.image = #imageLiteral(resourceName: "startPosition")
        }
        else if indexPath.row == 14{
            cell.laderJumpValueLabel.text = "(+4)"
        }else if indexPath.row == 16{
             cell.laderJumpValueLabel.text = "(-3)"
        }else if indexPath.row == 21{
            cell.laderJumpValueLabel.text = "(+1)"
        }else if indexPath.row == 23{
             cell.laderJumpValueLabel.text = "(-18)"
        }else if indexPath.row == 24{
             cell.diceImageView.image = #imageLiteral(resourceName: "Home")
        }else{
            cell.laderJumpValueLabel.text = ""
            cell.diceImageView.image = nil
        }
      
        if indexPath.row == firstPlayerPosition{
            cell.backgroundColor = .blue
            cell.diceImageView.image = #imageLiteral(resourceName: "Man")
        }else if indexPath.row == secondPlayerPosition{
            cell.backgroundColor = .red
            cell.diceImageView.image = #imageLiteral(resourceName: "manRed")
        }else{
            cell.backgroundColor = .yellow
            if indexPath.row == 0{
            cell.diceImageView.image = #imageLiteral(resourceName: "startPosition")
            }else if indexPath.row == 24{
               cell.diceImageView.image = #imageLiteral(resourceName: "Home")
            }else{
               cell.diceImageView.image = nil
            }
        }
        return cell
      }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       
        return CGSize(width: collectionView.frame.size.width/5.0,
                          height: collectionView.frame.size.height/5.0)
        }

}
    
    
    
    
    

